# team-sync

Claude Code Plugin, das Status, offene Fragen und Architekturentscheidungen
zwischen Teammitgliedern teilt, die am selben Repository arbeiten. Jede
Person nutzt weiterhin ihre eigene Claude Code Session mit ihrer eigenen
Membership, es gibt keinen zentralen Server und keine geteilte KI-Nutzung.

## Wie es funktioniert

Neben eurem Projekt-Repo liegt ein zweiter, lokaler Checkout desselben
Repos auf einem eigenen Branch `team-channel` (ein git worktree). Darin:

- `status/` - eine Datei pro Person, wird bei Sessionende automatisch
  aktualisiert: aktueller Branch, woran gearbeitet wurde, welche Dateien
  angefasst wurden.
- `questions/` - eine Datei pro Frage, angelegt per `/ask`, beantwortet
  per `/answer`.
- `decisions/` - eine Datei pro Architekturentscheidung, angelegt per
  `/decide`.

Bei jedem Sessionstart liest ein Hook automatisch den aktuellen Stand der
anderen, offene Fragen an einen selbst und die letzten Entscheidungen, und
gibt das als Kontext in die Session.

Der eigene Status wird auf zwei Wegen zurueckgeschrieben. Ein SessionEnd
Hook schreibt beim echten Beenden der Session, also bei /clear, /exit,
Logout. Fuer sehr lange Sessions, die nie geschlossen werden, reicht das
allein aber nicht, SessionEnd feuert dann erst am Ende eines ganzen
Arbeitstags. Deshalb gibt es zusaetzlich einen Stop Hook, der nach jeder
einzelnen Antwort prueft ob seit dem letzten Zwischenstand mehr als zehn
Minuten vergangen sind (einstellbar ueber
TEAM_SYNC_CHECKPOINT_SECONDS), und wenn ja, automatisch einen aktuellen
Zwischenstand schreibt und pusht. Damit bleibt der Status auch waehrend
einer stundenlangen Session halbwegs aktuell, ohne bei jeder einzelnen
Nachricht einen Commit zu erzeugen.

Fuer den Moment, in dem ein wichtiger Zwischenschritt fertig ist und das
Team sofort Bescheid wissen soll, gibt es zusaetzlich `/sync`. Das
schreibt sofort, unabhaengig vom Zehn-Minuten-Rhythmus, und mit einer
von Claude selbst formulierten Zusammenfassung statt der groben
automatischen Skriptlogik.

Jede Frage, jede Entscheidung und jeder Status ist eine eigene Datei.
Dadurch entstehen praktisch nie Merge-Konflikte, selbst wenn mehrere
Personen gleichzeitig committen und pushen.

## Setup

Einmalig pro Person, im Projekt-Repo, mit normalem Python (kein Claude
Code noetig dafuer):

```
python3 scripts/setup_channel.py
```

Die erste Person legt damit den `team-channel` Branch neu an, alle
weiteren checken ihn einfach als lokalen Worktree aus. Danach braucht
niemand mehr manuell etwas zu tun, die Hooks laufen automatisch mit jeder
Claude Code Session in diesem Projekt.

Falls bei euch `python3` nicht als Befehl existiert, sondern nur `python`,
das in `hooks/hooks.json` entsprechend anpassen.

## Nutzung im Alltag

- `/ask max wie hast du die Session-Verwaltung im Frontend geloest` -
  legt eine Frage fuer Max im Channel ab.
- `/answer` - zeigt offene Fragen an einen selbst, traegt Antworten ein.
- `/decide JWT statt Server-Session fuer Auth` - protokolliert eine
  Entscheidung mit Begruendung und verworfenen Alternativen.
- `/sync` - pusht sofort einen aktuellen, von Claude selbst formulierten
  Status, unabhaengig vom automatischen Zehn-Minuten-Rhythmus. Sinnvoll
  bei langen Sessions kurz nachdem etwas Wichtiges fertig geworden ist.

Wichtig fuer die Aktualitaet: das System ist nur so frisch wie euer
Push-Rhythmus. Kleine, haeufige Commits alle 15 bis 30 Minuten statt
stundenlanger Sessions am Stueck sorgen dafuer, dass die anderen bei
Sessionstart wirklich einen aktuellen Stand sehen.

## Bewusste Grenzen dieser ersten Version

- Kein Echtzeit-Chat zwischen laufenden Sessions. Kommunikation passiert
  ueber Pull bei Sessionstart und Push bei Sessionende, nicht live
  waehrend beide gleichzeitig arbeiten.
- Kein automatischer Contracts-Ordner fuer API-Schnittstellen. Das war in
  der Planung Phase drei, nach Status und Fragen, und ist hier bewusst
  noch nicht gebaut, damit sich erstmal die Grundfunktionen im Alltag
  bewaehren.
- Die Status-Zusammenfassung bei Sessionende ist bewusst simpel gehalten,
  die letzte Nutzer-Nachricht plus Liste angefasster Dateien, keine
  KI-generierte Zusammenfassung. Das liesse sich spaeter nachruesten,
  indem der Hook selbst `claude -p` mit der eigenen Session aufruft, aber
  das kostet Zeit im Kontingent der jeweiligen Person und sollte erst
  rein, wenn sich zeigt dass die einfache Version nicht reicht.
- Kein Erzwingen von irgendetwas. Die Hooks liefern Informationen, sie
  verhindern nicht dass zwei Leute versehentlich am selben Teil
  arbeiten. Das bleibt Teamdisziplin, das Tooling macht es nur
  wahrscheinlicher dass man es rechtzeitig merkt.

## Empfohlener Rollout

1. Erst zu zweit oder zu dritt mit `status` und `questions` mindestens
   eine Woche im echten Alltag testen.
2. Danach `decisions` aktiv nutzen, das zahlt sich erst nach einigen
   Wochen wirklich aus, wenn alte Entscheidungen nachgeschlagen werden.
3. Contracts fuer Schnittstellen als eigener, spaeterer Ausbauschritt.
