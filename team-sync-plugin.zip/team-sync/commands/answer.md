---
description: Zeigt offene Fragen aus dem Team-Channel und traegt Antworten ein
---

Der Nutzer moechte offene, an ihn gerichtete Fragen aus dem Team-Channel beantworten.

Gehe so vor:

1. Ermittle das Projektverzeichnis ueber CLAUDE_PROJECT_DIR (sonst aktuelles Verzeichnis) und daraus das Channel-Verzeichnis, ein Geschwisterordner mit Suffix "-channel".
2. Falls der Ordner fehlt, weise auf das Setup hin (`python3 scripts/setup_channel.py`) und stoppe.
3. Fuehre `git pull` im Channel-Verzeichnis aus.
4. Ermittle den eigenen Namen ueber `git config user.name` im Projektverzeichnis.
5. Durchsuche `questions/` nach Dateien, die im Feld "an:" den eigenen Namen enthalten und noch kein Feld "Antwort:" haben.
6. Zeige jede offene Frage einzeln an. Schlage anhand des aktuellen Projektkontexts eine Antwort vor, wenn du genug Informationen dazu hast, sonst frag den Nutzer direkt.
7. Trage die vom Nutzer bestaetigte Antwort unter einem neuen Abschnitt "Antwort:" mit Zeitstempel in dieselbe Datei ein.
8. Committe und pushe jede beantwortete Datei einzeln mit kurzer Commit-Message, direkt nachdem die Antwort eingetragen wurde, nicht erst am Ende.
9. Falls keine offenen Fragen vorliegen, sag das kurz und klar.
