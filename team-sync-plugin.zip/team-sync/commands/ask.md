---
description: Stellt eine Frage an ein Teammitglied ueber den Team-Channel
---

Der Nutzer moechte eine Frage fuer ein Teammitglied im gemeinsamen Team-Channel hinterlegen.

Argumente: $ARGUMENTS
Das erste Wort ist der Name der Zielperson, der Rest ist die eigentliche Frage.

Gehe so vor:

1. Ermittle das Projektverzeichnis ueber die Umgebungsvariable CLAUDE_PROJECT_DIR (falls nicht gesetzt, das aktuelle Arbeitsverzeichnis). Das Channel-Verzeichnis ist ein Geschwisterordner mit dem Namen des Projektordners plus dem Suffix "-channel".
2. Falls dieser Ordner nicht existiert, weise den Nutzer darauf hin, dass zuerst `python3 scripts/setup_channel.py` aus dem team-sync Plugin einmalig ausgefuehrt werden muss, und stoppe hier.
3. Fuehre im Channel-Verzeichnis `git pull` aus.
4. Ermittle deinen eigenen Namen ueber `git config user.name` im Projektverzeichnis.
5. Lege im Unterordner `questions/` eine neue Datei an, benannt nach dem Muster `JJJJ-MM-TT-HHMM-<deinname>-an-<zielperson>.md`.
6. Schreibe in die Datei: Empfaenger (Feld "an: <name>"), Absender, Zeitstempel, aktueller Branch, und die Frage klar formuliert. Ergaenze kurz den Kontext aus dem bisherigen Gespraech, falls das die Frage verstaendlicher macht.
7. Committe und pushe die neue Datei im Channel-Verzeichnis mit einer kurzen Commit-Message.
8. Bestaetige dem Nutzer knapp, dass die Frage hinterlegt und gepusht wurde.
