---
description: Protokolliert eine Architekturentscheidung im gemeinsamen Entscheidungsprotokoll
---

Der Nutzer moechte eine Entscheidung im Team-Channel protokollieren.

Argumente: $ARGUMENTS, eine kurze Beschreibung der getroffenen Entscheidung.

Gehe so vor:

1. Ermittle das Channel-Verzeichnis wie in den anderen Commands beschrieben (Geschwisterordner mit Suffix "-channel" neben CLAUDE_PROJECT_DIR). Falls es fehlt, weise auf das Setup hin und stoppe.
2. Fuehre `git pull` im Channel-Verzeichnis aus.
3. Ermittle den eigenen Namen ueber `git config user.name`.
4. Lege im Unterordner `decisions/` eine neue Datei an, benannt nach `JJJJ-MM-TT-HHMM-<deinname>-<kurztitel-in-worten>.md`.
5. Fuelle folgendes Format aus, basierend auf dem bisherigen Gespraechsverlauf dieser Session. Frag beim Nutzer nach, falls wichtige Punkte fehlen, rate nichts hinein:

```
# Entscheidung: <Titel>

Person: <dein Name>
Zeitstempel: <JJJJ-MM-TT HH:MM>

Worum ging es:
<kurz>

Was wurde entschieden:
<kurz>

Warum:
<Begruendung>

Verworfene Alternativen:
<Alternative 1 und warum verworfen>
<Alternative 2 und warum verworfen, falls vorhanden>
```

6. Committe und pushe die neue Datei im Channel-Verzeichnis mit einer kurzen Commit-Message.
7. Bestaetige dem Nutzer knapp, dass die Entscheidung protokolliert wurde.
