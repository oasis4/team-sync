---
description: Aktualisiert sofort den eigenen Status im Team-Channel, unabhaengig vom automatischen Zehn-Minuten-Rhythmus
---

Der Nutzer moechte seinen Status im Team-Channel jetzt sofort aktualisieren,
zum Beispiel weil gerade ein wichtiger Zwischenschritt fertig ist und das
Team davon wissen soll, ohne auf die naechste automatische Aktualisierung
zu warten.

Gehe so vor:

1. Ermittle das Channel-Verzeichnis wie in den anderen Commands (Geschwisterordner mit Suffix "-channel" neben CLAUDE_PROJECT_DIR). Falls es fehlt, weise auf das Setup hin und stoppe.
2. Fuehre `git pull` im Channel-Verzeichnis aus.
3. Ermittle den eigenen Namen ueber `git config user.name` und den aktuellen Branch.
4. Schreibe eine eigene, in Worten formulierte Zusammenfassung dessen, woran in dieser Session bisher gearbeitet wurde, basierend auf dem tatsaechlichen bisherigen Gespraechsverlauf, nicht nur auf der letzten Nachricht. Das darf und soll besser sein als die automatische Zwischenstandsdatei, weil du im Gegensatz zum Hintergrundskript den vollen Kontext der Session kennst.
5. Ueberschreibe damit die Datei `status/<eigener-name>.md` im Channel-Verzeichnis, im gleichen Format wie die automatischen Eintraege: Ueberschrift, Zuletzt aktiv, Branch, Woran gearbeitet wird, Angefasste Dateien.
6. Committe und pushe die Aenderung.
7. Fuehre im Projektverzeichnis (nicht im Channel-Verzeichnis) folgenden Befehl aus, damit der naechste automatische Zwischenstand nicht sofort wieder ueberschreibt: `mkdir -p .git && touch .git/team-sync-throttle`
8. Bestaetige dem Nutzer knapp, dass der Status aktualisiert und gepusht wurde.
