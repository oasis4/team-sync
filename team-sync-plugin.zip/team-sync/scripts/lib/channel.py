"""
Gemeinsame Hilfsfunktionen fuer die team-sync Hooks.

Grundidee: Neben dem eigentlichen Projekt-Repo liegt ein zweiter,
lokaler Checkout desselben Repos, aber auf dem Branch "team-channel".
Das ist ein git worktree, siehe scripts/setup_channel.py.
Darin liegen drei Ordner:

  status/     - eine Datei pro Person, aktueller Stand
  questions/  - eine Datei pro Frage, wird um eine Antwort ergaenzt
  decisions/  - eine Datei pro Architekturentscheidung

Alle Funktionen hier sind bewusst defensiv, ein Fehler in diesen
Skripten darf niemals eine Claude Code Session blockieren.
"""

import os
import re
import subprocess
import sys
import time
from pathlib import Path


def get_project_dir() -> Path:
    """Verzeichnis des eigentlichen Projekt-Repos."""
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())).resolve()


def get_channel_dir(project_dir: Path) -> Path:
    """
    Erwarteter Ort des team-channel Worktrees, ein Geschwisterordner
    des Projektverzeichnisses mit dem Suffix "-channel".
    Beispiel: /repos/mein-projekt  ->  /repos/mein-projekt-channel
    """
    return project_dir.parent / f"{project_dir.name}-channel"


def run_git(args, cwd, timeout=10):
    """
    Fuehrt einen git Befehl aus, gibt (erfolgreich, stdout) zurueck.
    Wirft nie eine Exception, damit ein Hook nie wegen eines
    Git-Problems die ganze Session blockiert.
    """
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode == 0, result.stdout.strip()
    except Exception:
        return False, ""


def get_agent_name(project_dir: Path) -> str:
    """
    Ermittelt einen stabilen, dateisystemtauglichen Namen fuer die
    aktuelle Person. Ueberschreibbar per Umgebungsvariable
    TEAM_AGENT_NAME, sonst aus git config user.name abgeleitet.
    """
    override = os.environ.get("TEAM_AGENT_NAME")
    if override:
        return slugify(override)

    ok, name = run_git(["config", "user.name"], cwd=project_dir)
    if ok and name:
        return slugify(name)

    return "unbekannt"


def slugify(text: str) -> str:
    text = text.strip().lower()
    text = text.replace("ae", "ae").replace("oe", "oe").replace("ue", "ue")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-") or "unbekannt"


def get_current_branch(project_dir: Path) -> str:
    ok, branch = run_git(["rev-parse", "--abbrev-ref", "HEAD"], cwd=project_dir)
    return branch if ok and branch else "unbekannt"


def ensure_subdirs(channel_dir: Path):
    for sub in ("status", "questions", "decisions"):
        (channel_dir / sub).mkdir(parents=True, exist_ok=True)


def pull_channel(channel_dir: Path):
    if not channel_dir.exists():
        return
    run_git(["pull", "--quiet"], cwd=channel_dir, timeout=15)


def push_channel(channel_dir: Path, message: str):
    if not channel_dir.exists():
        return
    run_git(["add", "-A"], cwd=channel_dir)
    ok, _ = run_git(["commit", "-m", message], cwd=channel_dir)
    # kein Fehler wenn es nichts zu committen gab
    run_git(["push", "--quiet"], cwd=channel_dir, timeout=20)


def get_throttle_marker(project_dir: Path) -> Path:
    """
    Liegt bewusst im lokalen .git Ordner des Projekts, nicht im
    team-channel. Wird nie synchronisiert, dient nur dazu, auf diesem
    einen Rechner zu merken wann zuletzt ein Zwischenstand gepusht wurde.
    """
    return project_dir / ".git" / "team-sync-throttle"


def should_checkpoint(project_dir: Path, min_interval_seconds: int) -> bool:
    marker = get_throttle_marker(project_dir)
    if not marker.exists():
        return True
    try:
        age = time.time() - marker.stat().st_mtime
    except Exception:
        return True
    return age >= min_interval_seconds


def touch_throttle(project_dir: Path):
    marker = get_throttle_marker(project_dir)
    try:
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.touch()
    except Exception:
        pass


def list_files_sorted(folder: Path):
    if not folder.exists():
        return []
    return sorted(folder.glob("*.md"))


def eprint(*args):
    print(*args, file=sys.stderr)
