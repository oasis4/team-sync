#!/usr/bin/env python3
"""
Laeuft nach jeder einzelnen Antwort von Claude (Stop Event), nicht nur
beim Sessionende. Gedacht fuer sehr lange Sessions, die nie ueber
/clear oder /exit beendet werden, wo SessionEnd erst abends feuern
wuerde. Damit dabei nicht bei jeder Nachricht ein Commit entsteht, ist
das Ganze standardmaessig auf einen Zwischenstand alle 10 Minuten pro
Projekt gedrosselt (TEAM_SYNC_CHECKPOINT_SECONDS ueberschreibbar).

Der Zwischenstand ist bewusst einfach gehalten, aus derselben simplen
Transkript-Auswertung wie session_end.py, keine zusaetzlichen
KI-Aufrufe, keine zusaetzlichen Kosten im Kontingent.
"""
import json
import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.channel import (
    get_project_dir,
    get_channel_dir,
    get_agent_name,
    get_current_branch,
    ensure_subdirs,
    pull_channel,
    push_channel,
    should_checkpoint,
    touch_throttle,
    eprint,
)
from session_end import extract_topic_and_files, MAX_FILES_LISTED

MIN_INTERVAL_SECONDS = int(os.environ.get("TEAM_SYNC_CHECKPOINT_SECONDS", "600"))


def read_hook_input():
    try:
        raw = sys.stdin.read()
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def main():
    hook_input = read_hook_input()
    transcript_path = hook_input.get("transcript_path", "")

    project_dir = get_project_dir()
    channel_dir = get_channel_dir(project_dir)
    if not channel_dir.exists():
        return

    force = os.environ.get("TEAM_SYNC_FORCE") == "1"
    if not force and not should_checkpoint(project_dir, MIN_INTERVAL_SECONDS):
        return

    ensure_subdirs(channel_dir)
    pull_channel(channel_dir)

    me = get_agent_name(project_dir)
    branch = get_current_branch(project_dir)
    topic, files = extract_topic_and_files(transcript_path)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    files_list = sorted(files)[:MAX_FILES_LISTED]
    files_block = "\n".join(f"- {f}" for f in files_list) if files_list else "- (keine Dateien erkannt)"

    content = f"""# Status: {me}

Zuletzt aktiv: {timestamp} (laufende Session, automatischer Zwischenstand)
Branch: {branch}

Woran gerade gearbeitet wird:
{topic or '(nicht ermittelbar)'}

Angefasste Dateien (bisher in dieser Session):
{files_block}
"""

    status_file = channel_dir / "status" / f"{me}.md"
    try:
        status_file.write_text(content, encoding="utf-8")
    except Exception as e:
        eprint(f"Zwischenstand konnte nicht geschrieben werden: {e}")
        return

    push_channel(channel_dir, f"status (zwischenstand): {me} - {timestamp}")
    touch_throttle(project_dir)


if __name__ == "__main__":
    main()
