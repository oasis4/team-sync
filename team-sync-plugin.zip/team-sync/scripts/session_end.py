#!/usr/bin/env python3
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.channel import (
    get_project_dir,
    get_channel_dir,
    get_agent_name,
    get_current_branch,
    ensure_subdirs,
    pull_channel,
    push_channel,
    eprint,
)

MAX_FILES_LISTED = 15


def read_hook_input():
    try:
        raw = sys.stdin.read()
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def extract_topic_and_files(transcript_path: str):
    """
    Liest die JSONL Session-Transkriptdatei und zieht daraus eine grobe
    Zusammenfassung: die erste Nutzer-Nachricht als Themenhinweis, plus
    die Menge der Dateien die per Edit/Write/MultiEdit angefasst wurden.
    Bewusst simpel gehalten, keine KI-Zusammenfassung noetig fuer diese
    erste Version.
    """
    topic = None
    files = set()

    if not transcript_path:
        return topic, files

    path = Path(transcript_path)
    if not path.exists():
        return topic, files

    try:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    continue

                if entry.get("type") == "user":
                    message = entry.get("message", {})
                    content = message.get("content")
                    if isinstance(content, str):
                        topic = content.strip()[:200]
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                topic = block.get("text", "").strip()[:200]
                                break

                if entry.get("type") == "assistant":
                    message = entry.get("message", {})
                    content = message.get("content", [])
                    if isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "tool_use":
                                if block.get("name") in ("Edit", "Write", "MultiEdit"):
                                    file_path = block.get("input", {}).get("file_path")
                                    if file_path:
                                        files.add(file_path)
    except Exception as e:
        eprint(f"Transkript konnte nicht vollstaendig gelesen werden: {e}")

    return topic, files


def main():
    hook_input = read_hook_input()
    transcript_path = hook_input.get("transcript_path", "")

    project_dir = get_project_dir()
    channel_dir = get_channel_dir(project_dir)

    if not channel_dir.exists():
        # Kein Setup, still beenden statt die Session zu stoeren
        return

    ensure_subdirs(channel_dir)
    pull_channel(channel_dir)

    me = get_agent_name(project_dir)
    branch = get_current_branch(project_dir)
    topic, files = extract_topic_and_files(transcript_path)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    files_list = sorted(files)[:MAX_FILES_LISTED]
    files_block = "\n".join(f"- {f}" for f in files_list) if files_list else "- (keine Dateien erkannt)"

    content = f"""# Status: {me}

Zuletzt aktiv: {timestamp}
Branch: {branch}

Woran gearbeitet wurde (letzte Nutzer-Nachricht der Session):
{topic or '(nicht ermittelbar)'}

Angefasste Dateien:
{files_block}
"""

    status_file = channel_dir / "status" / f"{me}.md"
    try:
        status_file.write_text(content, encoding="utf-8")
    except Exception as e:
        eprint(f"Status konnte nicht geschrieben werden: {e}")
        return

    push_channel(channel_dir, f"status: {me} - {timestamp}")


if __name__ == "__main__":
    main()
