#!/usr/bin/env python3
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.channel import (
    get_project_dir,
    get_channel_dir,
    get_agent_name,
    pull_channel,
    list_files_sorted,
    eprint,
)

MAX_DECISIONS = 5


def build_context() -> str:
    project_dir = get_project_dir()
    channel_dir = get_channel_dir(project_dir)

    if not channel_dir.exists():
        return (
            "Hinweis fuer den Nutzer: Es wurde kein team-channel Worktree "
            f"unter {channel_dir} gefunden. Falls das Team-Sync-System "
            "genutzt werden soll, einmalig 'python3 scripts/setup_channel.py' "
            "aus dem team-sync Plugin ausfuehren."
        )

    pull_channel(channel_dir)
    me = get_agent_name(project_dir)

    parts = []

    # Status der anderen Teammitglieder
    status_files = list_files_sorted(channel_dir / "status")
    others = [f for f in status_files if f.stem != me]
    if others:
        lines = ["Aktueller Stand der anderen Teammitglieder:"]
        for f in others:
            try:
                content = f.read_text(encoding="utf-8").strip()
            except Exception:
                continue
            lines.append(f"--- {f.stem} ---\n{content}")
        parts.append("\n".join(lines))

    # Offene Fragen an mich
    question_files = list_files_sorted(channel_dir / "questions")
    open_for_me = []
    for f in question_files:
        try:
            content = f.read_text(encoding="utf-8")
        except Exception:
            continue
        if f"an: {me}" in content.lower() and "antwort:" not in content.lower():
            open_for_me.append((f, content.strip()))

    if open_for_me:
        lines = ["Offene Fragen an dich aus dem Team-Channel (mit /answer beantworten):"]
        for f, content in open_for_me:
            lines.append(f"--- {f.name} ---\n{content}")
        parts.append("\n".join(lines))

    # Letzte Entscheidungen
    decision_files = list_files_sorted(channel_dir / "decisions")[-MAX_DECISIONS:]
    if decision_files:
        lines = ["Zuletzt getroffene Architekturentscheidungen im Team:"]
        for f in reversed(decision_files):
            try:
                content = f.read_text(encoding="utf-8").strip()
            except Exception:
                continue
            lines.append(f"--- {f.stem} ---\n{content}")
        parts.append("\n".join(lines))

    if not parts:
        return (
            "Team-Channel ist eingerichtet, aber noch leer. "
            "Kein Status, keine offenen Fragen, keine Entscheidungen bisher."
        )

    return "\n\n".join(parts)


def main():
    try:
        # stdin enthaelt die Hook-Payload, wird hier nicht gebraucht,
        # aber wir lesen sie weg damit Claude Code nicht blockiert
        sys.stdin.read()
    except Exception:
        pass

    try:
        context = build_context()
    except Exception as e:
        eprint(f"session_start hook fehlgeschlagen: {e}")
        context = ""

    if context:
        print(json.dumps({"additionalContext": context}))


if __name__ == "__main__":
    main()
