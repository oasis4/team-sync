#!/usr/bin/env python3
"""
Einmaliges Setup fuer den Team-Channel.

Wird von JEDEM Teammitglied einmal lokal ausgefuehrt, direkt im
Projekt-Repo, mit normalem Python (kein Claude Code Kontext noetig):

    python3 scripts/setup_channel.py

Ablauf:
  1. Falls der Branch "team-channel" auf dem Remote noch nicht existiert,
     wird er von der ersten Person angelegt, mit leerer Ordnerstruktur.
  2. Falls er schon existiert, wird er einfach als worktree daneben
     ausgecheckt.

Ergebnis: ein Ordner <projektname>-channel direkt neben dem Projektordner,
auf dem Branch team-channel, den die Hooks automatisch nutzen.
"""

import subprocess
import sys
from pathlib import Path

BRANCH = "team-channel"


def run(args, cwd=None, check=True):
    print(f"$ git {' '.join(args)}")
    result = subprocess.run(["git"] + args, cwd=cwd, text=True)
    if check and result.returncode != 0:
        print(f"Fehler bei: git {' '.join(args)}", file=sys.stderr)
        sys.exit(1)
    return result.returncode == 0


def remote_branch_exists(project_dir) -> bool:
    result = subprocess.run(
        ["git", "ls-remote", "--heads", "origin", BRANCH],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def main():
    project_dir = Path.cwd().resolve()
    channel_dir = project_dir.parent / f"{project_dir.name}-channel"

    if channel_dir.exists():
        print(f"Channel-Ordner existiert bereits: {channel_dir}")
        print("Nichts zu tun. Falls Probleme auftreten, den Ordner loeschen und neu ausfuehren.")
        return

    print("Aktuellen Branch merken, um am Ende dahin zurueckzukehren ...")
    current = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=project_dir, capture_output=True, text=True,
    ).stdout.strip()

    run(["fetch", "origin"], cwd=project_dir, check=False)

    if remote_branch_exists(project_dir):
        print(f"Branch {BRANCH} existiert bereits auf dem Remote, checke als worktree aus ...")
        run(["worktree", "add", str(channel_dir), BRANCH], cwd=project_dir)
    else:
        print(f"Branch {BRANCH} existiert noch nicht, lege ihn frisch an ...")
        run(["worktree", "add", "--orphan", "-b", BRANCH, str(channel_dir)], cwd=project_dir)

        for sub in ("status", "questions", "decisions"):
            d = channel_dir / sub
            d.mkdir(parents=True, exist_ok=True)
            (d / ".gitkeep").write_text("")

        readme = channel_dir / "README.md"
        readme.write_text(
            "# Team-Channel\n\n"
            "Dieser Branch enthaelt keinen Code, sondern nur Status, offene Fragen "
            "und Architekturentscheidungen des Teams. Wird automatisch von den "
            "team-sync Hooks gelesen und beschrieben. Nicht in main mergen.\n"
        )

        run(["add", "-A"], cwd=channel_dir)
        run(["commit", "-m", "team-channel: initiale Struktur"], cwd=channel_dir)
        run(["push", "-u", "origin", BRANCH], cwd=channel_dir)

    print()
    print(f"Fertig. Team-Channel liegt unter: {channel_dir}")
    print("Die Hooks des team-sync Plugins finden ihn automatisch, solange")
    print("dieser Ordner als direkter Geschwisterordner des Projekts bestehen bleibt.")


if __name__ == "__main__":
    main()
